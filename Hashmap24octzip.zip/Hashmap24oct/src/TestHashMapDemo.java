import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


public class TestHashMapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashMap<Long,String> telDir=new HashMap<Long, String>();

		telDir.put(8888108810L, "Vaishali S");
		telDir.put(6394405557L, "Harshita S");
		telDir.put(9177977123L, "Nadimpalli");
		telDir.put(8888108810L, "Abhishek S");
		telDir.put(9966541256L, "Rahul G");

		System.out.println(telDir);

		/*you cannot use Iterator directly on hashmap,
		so first convert hashmap into set */
		Set<Map.Entry<Long,String>> dirSet=telDir.entrySet();
		Iterator<Map.Entry<Long, String>> itSet=dirSet.iterator();

		while(itSet.hasNext())
		{
			Map.Entry entry=itSet.next();
			System.out.println("Mobile:" + entry.getKey() + "   Name:" +
					entry.getValue());
		}
		System.out.println("***************************************");

		//printing only the keys
		Set s=telDir.keySet();
		Iterator <Long>it=s.iterator();
		while(it.hasNext())
		{
			Long mob=it.next();
			System.out.println("keys: " + mob);
		}

		System.out.println("***************************************");

		//printing only the values
		Collection<String> s2=telDir.values();
		Iterator it2=s2.iterator();
		while(it2.hasNext())
		{
			String names=(String)it2.next();
			System.out.println("names: " + names);
		}

		System.out.println("*****************************************");
		
		System.out.println("Enter the number to be searched:");
		Scanner sc=new Scanner(System.in);
		Long mobnum=sc.nextLong();
		Iterator it3=s.iterator();
		while(it3.hasNext())
		{
			long mob=(long) it3.next();
			if(mob==mobnum)
			{
				System.out.println("Mobile Number: " + mob + "  Name: " + telDir.get(mob)); 
			}	
		}
		System.out.println("*****************************************");
		
		System.out.println("Enter the name to be searched:");
		String name=sc.next();
		Iterator it4=s2.iterator();
		while(it4.hasNext())
		{
			long mob=(long) it3.next();
			if(mob==mobnum)
			{
				System.out.println("Mobile Number: " + mob + "  Name: " + telDir.get(mob)); 
			}
			
				
		}



	}

}
