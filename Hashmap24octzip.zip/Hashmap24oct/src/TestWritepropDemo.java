import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;


public class TestWritepropDemo {

	public static void main(String[] args) {
		
		try {
			FileOutputStream fos=new FileOutputStream("comInfo.properties");
			Properties compProps=new Properties();
			compProps.setProperty("compname", "Capgemini");
			compProps.setProperty("compLoc", "Pune");
			compProps.setProperty("country", "India");
			
			compProps.store(fos,"This is comp Info");
			System.out.println("Data is saved in properties file");
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		}

	}

}
