import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;


public class TestReadpropDemo {

	public static void main(String[] args) 
	{
		try {
			FileInputStream fis=new FileInputStream("userInfo.properties");
			Properties myProps=new Properties();
			myProps.load(fis);
			
			System.out.println("Username: "+myProps.getProperty("username"));
			System.out.println("Password: "+myProps.getProperty("password"));
			
			Set<Map.Entry<Object,Object>> myPropsIt=myProps.entrySet();
			
			
			Iterator <Map.Entry<Object,Object>> it=myPropsIt.iterator();
		    
			while(it.hasNext())
			{
				Map.Entry<Object, Object> entry=it.next();
				String keyName=(String)entry.getKey();
				String val=(String)entry.getValue();
				System.out.println("Key:"+keyName + "   Value:" + val);
			}
		}
			
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}
