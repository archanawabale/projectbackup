package HotelBooking;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HotelBookingFactory {

	WebDriver driver;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement FirstNameTxt;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement LastNameTxt;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement mobileNo;
	
	@FindBy(className="btn")
	@CacheLookup
	WebElement confirmBtn;
	
	@FindBy(id="txtGender1")
	@CacheLookup
	WebElement gender1;
	
	@FindBy(id="txtGender2")
	@CacheLookup
	WebElement gender2;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;
	
	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement cardHoldername;
	
	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement debitCardno;
	
	@FindBy(id="txtCvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement expmonth;
	
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement expyear;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[12]/td[2]/input[1]")
	WebElement check1;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[12]/td[2]/input[2]")
	WebElement check2;

	public HotelBookingFactory() {
		
	}

	public HotelBookingFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void  setFirstName(String name) {
		FirstNameTxt.sendKeys(name);
	}
	
	public void  setLastName(String name) {
		LastNameTxt.sendKeys(name);
	}
	
	public void  setemail(String name) {
		email.sendKeys(name);
	}
	
	public void  setmobile(String name) {
		mobileNo.sendKeys(name);
	}
	
	public void clickLoginButton() {
		confirmBtn.click();
	}
	
	public String getCity() {
		String name=city.getText();
		return name;
	}
	
	public void setCity(String name) {
		city.sendKeys(name);
		
	}
	
	public String getState(String name) {
		String statename=state.getText();
		return statename;
	}
	
	public void setState(String name) {
		state.sendKeys(name);
		
	}
	
	public void setCardHoldername(String name) {
		cardHoldername.sendKeys(name);
		
	}
	
	public void setGender(String gen) {
		if(gen.equalsIgnoreCase("female"))
			gender2.click();
		else
			gender1.click();
	}

	public void setdebitCardno(String name) {
		debitCardno.sendKeys(name);
		
	}
	
	public void setCVV(String name) {
		cvv.sendKeys(name);
		
	}
	
	public void setExpMonth(String name) {
		expmonth.sendKeys(name);
		
	}
	
	public void setExpYear(String name) {
		expyear.sendKeys(name);
		
	}
	
	public void setRoomType(String type) {
		if(type.equalsIgnoreCase("ac"))
			check1.click();
		else
			check2.click();
	}
	
	
}
