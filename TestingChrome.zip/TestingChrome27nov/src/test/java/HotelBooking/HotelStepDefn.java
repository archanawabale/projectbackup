package HotelBooking;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelStepDefn{

	HotelBookingFactory loginPage; 
	WebDriver driver;
	
	@Given("^User is on hotel booking form page$")
	public void user_is_on_hotel_booking_form_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\bdd software\\chromedriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("D:\\bdd software\\HotelBookingDemo\\hotelbooking.html");
		loginPage= new HotelBookingFactory(driver);
	    System.out.println("page is loaded in browser");
	}

	@When("^First Name is not entered$")
	public void first_Name_is_not_entered() throws Throwable {
		loginPage.setFirstName("");
		loginPage.clickLoginButton();
		    
	}

	@Then("^Display Alert 'Please fill the First Name'$")
	public void display_Alert_Please_fill_the_First_Name() throws Throwable {
		String expErrMsg="Please fill the First Name";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
		driver.switchTo().alert().accept();
		//driver.close();
	}

	@When("^First Name is entered but Last Name is not entered$")
	public void first_Name_is_entered_but_Last_Name_is_not_entered() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please fill the Last Name'$")
	public void display_Alert_Please_fill_the_Last_Name() throws Throwable {
		String expErrMsg="Please fill the Last Name";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
		driver.switchTo().alert().accept();
		//driver.close();
	}

	@When("^First Name and Last Name is entered but email is empty$")
	public void first_Name_and_Last_Name_is_entered_but_email_is_empty() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please fill the Email'$")
	public void display_Alert_Please_fill_the_Email() throws Throwable {
		String expErrMsg="Please fill the Email";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
		driver.switchTo().alert().accept();
		//driver.close();
	}
	
	@When("^Email is invalid$")
	public void email_is_invalid() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("12345");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please enter valid Email Id\\.'$")
	public void display_Alert_Please_enter_valid_Email_Id() throws Throwable {
		String expErrMsg="Please enter valid Email Id.";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
		driver.switchTo().alert().accept();
		//driver.close();
	}

	
	@When("^First Name and Last Name and email is entered but mobile number is empty$")
	public void first_Name_and_Last_Name_and_email_is_entered_but_mobile_number_is_empty() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please fill the Mobile No.'$")
	public void display_Alert_Please_fill_the_Mobile_No() throws Throwable {
		String expErrMsg="Please fill the Mobile No.";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
		driver.switchTo().alert().accept();
		//driver.close();
	}
	
	@When("^Invalid Mobile number is entered$")
	public void invalid_Mobile_number_is_entered() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("234545");
		loginPage.clickLoginButton();
	}
	
	@When("^Mobile number is (\\d+) digit but invalid$")
	public void mobile_number_is_digit_but_invalid(int arg1) throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("2345612345");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please enter valid Contact no\\.'$")
	public void display_Alert_Please_enter_valid_Contact_no() throws Throwable {
		String expErrMsg="Please enter valid Contact no.";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
		driver.switchTo().alert().accept();
		//driver.close();
	}
	
	@When("^Gender not selected$")
	public void gender_not_selected() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("8983542615");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please Select the Gender'$")
	public void display_Alert_Please_Select_the_Gender() throws Throwable {
		String expErrMsg="Please Select the Gender";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
	}
	
	@When("^City is not selected$")
	public void city_is_not_selected() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("8983542615");
		loginPage.setGender("Female");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please select city.'$")
	public void display_Alert_Please_select_city() throws Throwable { 
		String expErrMsg="Please select city";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
		
	}
	

@When("^State is not selected$")
	public void state_is_not_selected() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("8983542615");
		loginPage.setGender("Female");
		loginPage.setCity("Pune");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please select state\\.'$")
	public void display_Alert_Please_select_state() throws Throwable {
		String expErrMsg="Please select state";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
	}

	@When("^Room type not entered$")
	public void room_type_not_entered() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("8983542615");
		loginPage.setGender("Female");
		loginPage.setCity("Pune");
		loginPage.setState("Maharashtra");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please select the Room type'$")
	public void display_Alert_Please_select_the_Room_type() throws Throwable {
		String expErrMsg="Please select the Room type";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
	}

	@When("^Card Holder name is not entered$")
	public void card_Holder_name_is_not_entered() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("8983542615");
		loginPage.setGender("Female");
		loginPage.setCity("Pune");
		loginPage.setState("Maharashtra");
		loginPage.setRoomType("AC");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please enter card holder name\\.'$")
	public void display_Alert_Please_enter_card_holder_name() throws Throwable {
		String expErrMsg="Please fill the Card holder name";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
	}


	@When("^Debit Card Number not entered$")
	public void debit_Card_Number_not_entered() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("8983542615");
		loginPage.setGender("Female");
		loginPage.setCity("Pune");
		loginPage.setState("Maharashtra");
		loginPage.setRoomType("AC");
		loginPage.setCardHoldername("ARCHANA WABALE");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please fill the Debit card Number'$")
	public void display_Alert_Please_fill_the_Debit_card_Number() throws Throwable {
		String expErrMsg="Please fill the Debit card Number";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
		driver.switchTo().alert().accept();
		//driver.close();
	}
	
	@When("^CVV not entered$")
	public void cvv_not_entered() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("8983542615");
		loginPage.setGender("Female");
		loginPage.setCity("Pune");
		loginPage.setState("Maharashtra");
		loginPage.setRoomType("AC");
		loginPage.setCardHoldername("ARCHANA WABALE");
		loginPage.setdebitCardno("1345456185419623");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please fill the CVV'$")
	public void display_Alert_Please_fill_the_CVV() throws Throwable {
		String expErrMsg="Please fill the CVV";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
		driver.switchTo().alert().accept();
		//driver.close();
	}
	
	@When("^Expiration month not entered$")
	public void expiration_month_not_entered() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("8983542615");
		loginPage.setGender("Female");
		loginPage.setCity("Pune");
		loginPage.setState("Maharashtra");
		loginPage.setRoomType("AC");
		loginPage.setCardHoldername("ARCHANA WABALE");
		loginPage.setdebitCardno("1345456185419623");
		loginPage.setCVV("544");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please fill expiration month'$")
	public void display_Alert_Please_fill_expiration_month() throws Throwable {
		String expErrMsg="Please fill expiration month";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
		driver.switchTo().alert().accept();
		//driver.close();
	}

	@When("^Expiration year not entered$")
	public void expiration_year_not_entered() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("8983542615");
		loginPage.setGender("Female");
		loginPage.setCity("Pune");
		loginPage.setState("Maharashtra");
		loginPage.setRoomType("AC");
		loginPage.setCardHoldername("ARCHANA WABALE");
		loginPage.setdebitCardno("1345456185419623");
		loginPage.setCVV("544");
		loginPage.setExpMonth("May");
		loginPage.clickLoginButton();
	}

	@Then("^Display Alert 'Please fill expiration year'$")
	public void display_Alert_Please_fill_expiration_year() throws Throwable {
		String expErrMsg="Please fill the expiration year";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
		driver.switchTo().alert().accept();
		//driver.close();
	}

	@When("^Everything is filled$")
	public void everything_is_filled() throws Throwable {
		loginPage.setFirstName("Archana");
		loginPage.setLastName("Wabale");
		loginPage.setemail("abc@gmail.com");
		loginPage.setmobile("8983542615");
		loginPage.setGender("Female");
		loginPage.setCity("Pune");
		loginPage.setState("Maharashtra");
		loginPage.setRoomType("AC");
		loginPage.setCardHoldername("ARCHANA WABALE");
		loginPage.setdebitCardno("1345456185419623");
		loginPage.setCVV("544");
		loginPage.setExpMonth("May");
		loginPage.setExpYear("2029");
		loginPage.clickLoginButton();
	}

	@Then("^Redirect user to Success page$")
	public void redirect_user_to_Success_page() throws Throwable {
		driver.navigate().to("D:\\bdd software\\HotelBookingDemo\\success.html");
	}

	

	
}
