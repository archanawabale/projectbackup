package TestChrome;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefn {

	LoginPageFactory loginPage; 
	WebDriver driver;
	
	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\bdd software\\chromedriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("D:\\bdd software\\HotelBookingDemo\\login.html");
		loginPage= new LoginPageFactory(driver);
	    System.out.println("page is loaded in browser");
	    
	    
	}

	@When("^Username password is blank$")
	public void username_password_is_blank() throws Throwable {
	   loginPage.setUserName("");
	   loginPage.setPassword("");
	   loginPage.clickLoginButton();
	    
	}

	@Then("^Display Error message 'Please enter username'$")
	public void display_Error_message_Please_enter_username() throws Throwable {
	    String actualErrrMsg=loginPage.getUserNameError();
	    String expErrorMsg="* Please enter userName.";
	    Assert.assertEquals(expErrorMsg, actualErrrMsg);
	    driver.close();
	}

	

	@When("^username is given but password is blank$")
	public void username_is_given_but_password_is_blank() throws Throwable {
		loginPage.setUserName("Archana");
		loginPage.setPassword("");
		loginPage.clickLoginButton();
	}

	@Then("^Display Error message 'Please enter password'$")
	public void display_Error_message_Please_enter_password() throws Throwable {
		String actualErrorMsg=loginPage.getPasswordError();
	    String expErrorMsg="* Please enter password.";
	    Assert.assertEquals(expErrorMsg, actualErrorMsg);
		driver.close();
		
	}
	
	@When("^Invalid username password is entered$")
	public void invalid_username_password_is_entered() throws Throwable {
		loginPage.setUserName("Archana");
		loginPage.setPassword("Archana");
		loginPage.clickLoginButton();
	}

	@Then("^Display alert 'Invalid login'$")
	public void display_alert_Invalid_login() throws Throwable {
		String expErrMsg="Invalid login! Please try again!";
		String actErrMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(actErrMsg, expErrMsg); 
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@When("^Valid username password is entered$")
	public void valid_username_password_is_entered() throws Throwable {
		loginPage.setUserName("Capgemini");
		loginPage.setPassword("Capgemini123");
		loginPage.clickLoginButton();
	}
	
	@Then("^Redirect user to HotelBooking page$")
	public void redirect_user_to_HotelBooking_page() throws Throwable {
	    driver.navigate().to("D:\\bdd software\\HotelBookingDemo\\hotelbooking.html");
	}

	
}
