package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Person;
import com.cg.service.TestServiceImpl;
import com.cg.service.TestServiceInterface;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	Person p=new Person();
	TestServiceInterface service= new TestServiceImpl();
	ArrayList <String> errList =new ArrayList(); 
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		String name=request.getParameter("txtName");
		
		if(service.validateName(name))
		{
			p.setName(name);
			request.setAttribute("person1",p);
			RequestDispatcher rd=request.getRequestDispatcher("Success");
			rd.forward(request, response);
			
		}
		else
		{
			ArrayList<String> validationErrors = null;
			validationErrors.add("Please enter value for name.It should not be empty");
			request.setAttribute("errList","validationErrors");
			RequestDispatcher rd=request.getRequestDispatcher("Error");
			rd.forward(request, response);
		}
		
	}

}
