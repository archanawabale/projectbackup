package com.cg.service;

public class TestServiceImpl implements TestServiceInterface{

	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		
		return false;
	}

	
}
