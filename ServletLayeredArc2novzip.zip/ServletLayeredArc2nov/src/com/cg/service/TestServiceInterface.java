package com.cg.service;

public interface TestServiceInterface {

	boolean validateName(String name);

	

}
