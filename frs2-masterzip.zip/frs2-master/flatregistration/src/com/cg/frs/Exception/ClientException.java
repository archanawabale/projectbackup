package com.cg.frs.Exception;


public class ClientException extends Exception {
	public ClientException(String msg){
		super(msg);
	}
}