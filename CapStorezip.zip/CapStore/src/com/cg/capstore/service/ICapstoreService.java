package com.cg.capstore.service;

import com.cg.capstore.dto.CapStoreRevenue;
import com.cg.capstore.dto.Product;

public interface ICapstoreService {

	public int quantity(String product);
	public double revenue(int revenue,String prodName);
	public void insertdata(CapStoreRevenue rev);
	
}
