package com.cg.capstore.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Revenue")
public class CapStoreRevenue {

	@Id
	@Column(name="revenue_id", length=10)
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int revenueId;
	
	@Column(name="revenue", length=10)
	private double revenue;
	
	
	public double getRevenue() {
		return revenue;
	}
	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}
	public int getRevenueId() {
		return revenueId;
	}
	public CapStoreRevenue() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CapStoreRevenue(int revenueId, double revenue) {
		super();
		this.revenueId = revenueId;
		this.revenue = revenue;
	}
	public void setRevenueId(int revenueId) {
		this.revenueId = revenueId;
	}
	
	
	
}
