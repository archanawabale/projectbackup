package com.cg.bank;

public class App 
{
	public static void main( String[] args )
    {
		App app=new App();
        System.out.println( "Hello World!" );
		System.out.println("Sum is : "+ app.add(30,50));
		System.out.println( "Welcome to :"+ app.sayHello() );
    }
	
	public int add(int num1, int num2)
	{
		return(num1+num2);
	}
	
	public String sayHello()
	{
		return "Capgemini";
	}
}
