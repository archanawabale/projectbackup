package com.cg.bank;

import static org.junit.Assert.*;
import org.junit.*;
import org.junit.Test;

public class AppTest 
{
    
	static App app=null;
	@BeforeClass
	public static void setup()
	{
		app=new App();
		System.out.println("This is setup call");
	}
	
	@AfterClass
	public static void teardown()
	{
		app=null;
		System.out.println("This is teardown call");
	}
	
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
	
	@Test
    public void testAdd1()
    {
        Assert.assertEquals(40,app.add(10,30));
    }
	
	@Test
	public void testAdd2()
    {
        Assert.assertEquals(0,app.add(0,0));
    }
	
	@Test
	public void testSayHello()
    {
        Assert.assertEquals("Capgemini",app.sayHello());
    }
}
   
