package com.cg.ems.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {

	static String url=null;
	static String usn=null;
	static String pwd=null;
	public static Connection getCon() throws SQLException, IOException
	{
		Properties props=loadDbinfo();
		url=props.getProperty("dburl");
		usn=props.getProperty("dbuseName");
		pwd=props.getProperty("dbpassword");
		Connection con=null;
		if(con==null)
		{
			con=DriverManager.getConnection(url,usn,pwd);
			return con;
		}
		return con;
	}
	public static Properties loadDbinfo() throws IOException
	{
		FileReader fr=new FileReader("dbinfo.properties");
		Properties myProps=new Properties();
		myProps.load(fr);
		return myProps;
	}
}
