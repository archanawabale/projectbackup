package com.cg.ems.service;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.regex.Pattern;

import com.cg.ems.dao.EmpDAO;
import com.cg.ems.dao.EmpDAOImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;


public class EmpServiceImpl implements EmpService{

	
	EmpDAO empDao=null;
	public EmpServiceImpl()
	{
		empDao=new EmpDAOImpl();
	}
	@Override
	public int addEmployee(Employee ee) throws EmployeeException {
		// TODO Auto-generated method stub
		
		return empDao.addEmployee(ee);
	}

	@Override
	public HashSet<Employee> fetchAllEmp() {
		// TODO Auto-generated method stub
		return empDao.fetchAllEmp();
	}

	@Override
	public Employee getEmpById(int empId) {
		// TODO Auto-generated method stub
		return empDao.getEmpById(empId);
	}

	@Override
	public HashSet<Employee> searchEmpByName(String name) {
		// TODO Auto-generated method stub
		return empDao.searchEmpByName(name);
	}

	@Override
	public int deleteEmp(int empId) {
		// TODO Auto-generated method stub
		return empDao.deleteEmp(empId);
	}

	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		// TODO Auto-generated method stub
		return empDao.updateEmp(empId, newName, newSal);
	}

	@Override
	public boolean validateDigit(String num) throws EmployeeException {
		// TODO Auto-generated method stub
		//Integer input=new Integer(num);
		//String inputStr=input.toString();
		String digitPatter="[0-9]+";
				if(Pattern.matches(digitPatter, num))
				{
					return true;
				}
				else
				{
					throw new EmployeeException("Invalid input"+ "Only digits are allowed ex. 4577");
				}
			
	}

	@Override
	public boolean validateName(String name) throws EmployeeException {
		// TODO Auto-generated method stub
		String namePatter="[A-Z][a-z]+";
				if(Pattern.matches(namePatter, name))
				{
					return true;
				}
				else
				{
					throw new EmployeeException("Invalid input"+ "Only characters are allowed and should start in capital");
				}
		
	}
	@Override
	public Date convertFromStrToLocalDate(String dtStr) {
		
		DateTimeFormatter myFormat=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate date=LocalDate.parse(dtStr, myFormat);
		java.sql.Date sqlDob=java.sql.Date.valueOf(date);
		
		return sqlDob;
	}
	@Override
	public Period experienceOfEmp(int empID) {
		/*LocalDate today=LocalDate.now();
		Period p=null;
		HashSet<Employee> emp= CollectionUtil.getAllEmp();
		Iterator<Employee> it=emp.iterator();
		while(it.hasNext())
		{
			
			Employee e=it.next();
			if(empID==e.getEmpId())
			{
			p=Period.between(e.getEmpDOJ(),today );
			
			}
		}
		;*/ return null;
	}

}
