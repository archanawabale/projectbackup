package com.cg.junit;

public @interface BeforeClass {

}
