import java.util.List;

import javax.persistence.EntityManager;

import com.cg.bean.Address;
import com.cg.bean.Student;
import com.cg.dao.StudentDaoImpl;
import com.cg.util.JPAUtil;


public class TestStuOneToOneClient {

	static EntityManager em=null;
	static StudentDaoImpl stuDao=null;
	public static void main(String[] args) {
		
		stuDao=new StudentDaoImpl();
		
		em=JPAUtil.getEntityManager();
		Address address1=new Address();
		address1.setCity("Karla");
		address1.setState("UK");
		address1.setStreet("KM Road");
		address1.setZipCode("60006");
		
		Address address2=new Address();
		address2.setCity("Surat");
		address2.setState("Gujurat");
		address2.setStreet("Gm Road");
		address2.setZipCode("9865");
		
		Student st1=new Student();
		st1.setStuName("Fualk");
		st1.setStuAdd(address1);
		
		Student st2=new Student();
		st2.setStuName("Tewd");
		st2.setStuAdd(address1);
		
		stuDao.addStudent(st1);
		stuDao.addStudent(st2);
		System.out.println("Both students are added");
		
		System.out.println("------------------------------");
		List stList=stuDao.getAllStudents();
		System.out.println(stList);
		
	}

}
