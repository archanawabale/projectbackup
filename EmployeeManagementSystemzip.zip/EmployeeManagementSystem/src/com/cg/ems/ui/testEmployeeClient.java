package com.cg.ems.ui;

import java.time.Period;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmpService;
import com.cg.ems.service.EmpServiceImpl;

public class testEmployeeClient {
	
	static Scanner sc=null;
	static EmpService empSer=null;
	public static void main(String[] args) throws EmployeeException
	{
		sc=new Scanner(System.in);
		empSer=new EmpServiceImpl();
		int choice=0;
		while(true)
		{
			System.out.println("What do u want to do??");
			System.out.println("1.Add Emp\t 2.Fetch all Emp\n");
			System.out.println("3.Delete Emp\t 4.Seacrh Emp by Id\n");
			System.out.println("5.Search Emp by name\t 6.Update Emp\n");
			System.out.println("7.Find experience \t 8.Exit\n");
			System.out.println("Enter ur choice\n");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: addEmp();
					break;
			case 2: showEmpInfo();
					break;
			case 3: deleteEmp();
					break;
			case 4: SearchEmpbyId();
					break;
			case 5: SearchEmpbyName();
					break;
			case 6: updateEmp();
					break;
			case 7: experienceOfEmp();
					break;
			default: System.exit(0);
			}
			
			


		}
	}
	private static void experienceOfEmp() {
		System.out.println("Enter employee Id: ");
		int empID = sc.nextInt();
		Period p1=empSer.experienceOfEmp(empID);
		System.out.println(p1.getYears()+" years"+p1.getMonths()+" months"+p1.getDays()+" days");
		
	}
	private static void updateEmp() throws EmployeeException {
		// TODO Auto-generated method stub
		System.out.println("Enter Employee ID:");
		int eid=sc.nextInt();
		System.out.println("Enter Employee name:");
		String name=sc.next();
		System.out.println("Enter Employee Salary:");
		float sal=sc.nextFloat();
		Employee e=empSer.updateEmp(eid, name, sal);
		System.out.println(e);
		
	}
	private static void SearchEmpbyName() {
		// TODO Auto-generated method stub
		System.out.println("Enter Employee name:");
		String empname= sc.next();
		HashSet <Employee> ee1=empSer.searchEmpByName(empname);
		System.out.println(ee1);
	}
	
	private static void SearchEmpbyId() {
		// TODO Auto-generated method stub
		System.out.println("Enter Employee ID:");
		int n= sc.nextInt();
		Employee e=empSer.getEmpById(n);
		System.out.println(e);
		
	}
	
	private static void deleteEmp() {
		// TODO Auto-generated method stub
		System.out.println("Enter emp id");
		int eid=sc.nextInt();
		int n=empSer.deleteEmp(eid);
		System.out.println(eid+"Deleted successfully");
	}
	private static void showEmpInfo() 
	{
		HashSet<Employee> empSet=empSer.fetchAllEmp();
		Iterator<Employee> it=empSet.iterator();
		System.out.println("-------------------------------");
		System.out.println("EMPID/t/tEMPNAME\t\tEMPSalary");
		while(it.hasNext())
		{
			Employee ee=it.next();
			System.out.println(ee.getEmpId()+"\t\t"+ee.getEmpName()+"\t\t"+ee.getEmpSal()+"\t\t" + ee.getEmpDOJ()+"\t\t");
			
		}
		System.out.println("----------------------------------");
	}
	private static void addEmp() 
	{
		System.out.println("Enter Emp ID:");
		String eid=sc.next();
		try
		{
			if(empSer.validateDigit(eid))
			{
				System.out.println("Enter Emp name:");
				String nm=sc.next();
				if(empSer.validateName(nm))
				{
					System.out.println("Enter Salary");
					float sal=sc.nextFloat();
					System.out.println("Enter DOJ (dd-MM-yyyy):");
					String empDOJStr=sc.next();
					Employee ee=new Employee(Integer.parseInt(eid),nm,sal,empSer.convertFromStrToLocalDate(empDOJStr));
					int empId=empSer.addEmployee(ee);
					System.out.println(empId + "Added Successfully");
				}
			}
		}
		catch(EmployeeException e)
		{
			e.printStackTrace();
		}
		
	}
}
