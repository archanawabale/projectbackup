import java.util.*;
import java.util.ArrayList;


public class Productnames {

	public static void main(String[] args) {

		ArrayList<String> list=new ArrayList<String>();

		list.add("Pen");
		list.add("Chalk");
		list.add("House");
		list.add("Almond");
		list.add("Watch");
		list.add("Joker");

		Iterator it=list.iterator();  
		while(it.hasNext()){  
			System.out.println(it.next());  
		}
		System.out.println("*************************************");
		System.out.println("In sorted order");
		Collections.sort(list);
		}

	}
