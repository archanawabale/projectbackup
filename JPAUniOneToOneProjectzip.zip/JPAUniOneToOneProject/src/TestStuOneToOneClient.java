import java.util.List;

import javax.persistence.EntityManager;

import com.cg.bean.Address;
import com.cg.bean.Student;
import com.cg.dao.StudentDaoImpl;
import com.cg.util.JPAUtil;


public class TestStuOneToOneClient {

	static EntityManager em=null;
	static StudentDaoImpl stuDao=null;
	public static void main(String[] args) {
		
		stuDao=new StudentDaoImpl();
		
		em=JPAUtil.getEntityManager();
		Address address1=new Address();
		address1.setCity("Kanpur");
		address1.setState("UP");
		address1.setStreet("Mg Road");
		address1.setZipCode("600008");
		
		Address address2=new Address();
		address2.setCity("Mumbai");
		address2.setState("MS");
		address2.setStreet("JM Road");
		address2.setZipCode("411056");
		
		Student st1=new Student();
		st1.setStuName("A");
		st1.setStuAdd(address1);
		
		Student st2=new Student();
		st2.setStuName("Tejas");
		st2.setStuAdd(address1);
		
		stuDao.addStudent(st1);
		stuDao.addStudent(st2);
		System.out.println("Both students are added");
		
		System.out.println("------------------------------");
		List stList=stuDao.getAllStudents();
		System.out.println(stList);
		
	}

}
