package com.cg.demo.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MyController {

		@Autowired
		ITrainingService trainingservice;
		
		@RequestMapping(value="schedule",method=RequestMethod.GET)
		public ModelAndView getAllDetail() {
			List<Client> clientData=trainingservice.getAllDetail();
			return new ModelAndView("ScheduledSessions", "data", clientData);
		}
		@RequestMapping(value="Enroll Me",method=RequestMethod.GET)
		public ModelAndView dataDisplay(@RequestParam("name") String cname) {
			
			return new ModelAndView("Success", "ename", cname);
		}
	
}
