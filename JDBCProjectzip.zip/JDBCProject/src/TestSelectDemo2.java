import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


public class TestSelectDemo2 {
	public static void main(String[] args)
	{
		Connection con=null;
		Statement st=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String uid="system";
		String pwd="corp123";
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(url,uid,pwd);
			st=con.createStatement();
			rs=st.executeQuery(QueryMapper.SELECTQRY1);
			ResultSetMetaData rsmd=rs.getMetaData();
			
			int columnCount=rsmd.getColumnCount();
			System.out.println("Column Count: "+ columnCount);
			for(int i=0;i<columnCount;i++)
			{
				System.out.println("Column Name: "+ rsmd.getColumnName(i) + "Column Type: "+rsmd.getColumnTypeName(i));
			}
			
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
}

