
public interface QueryMapper {
	
	public static final String SELECTQRY1="SELECT * FROM emp";
	public static final String SELECTQRY2="SELECT * FROM emp WHERE emp_id=?";
	public static final String INSERTQRY1="INSERT INTO emp VALUES (333,'Sunil',34000,SYSDATE)";
	public static final String INSERTQRY2="INSERT INTO emp (emp_id,emp_name,emp_sal)" + "VALUES (444,'Amit',60000)";
	public static final String INSERTQRY3="INSERT INTO emp (emp_id,emp_name,emp_sal)" + "VALUES(?,?,?)"; //dynamic query, bcuz right now no values are inserted
	public static final String DELETEQRY1="DELETE FROM emp WHERE emp_id=?";
	public static final String UPDATEQRY1="UPDATE emp SET emp_name=?, emp_sal=? WHERE emp_id=?";
}

