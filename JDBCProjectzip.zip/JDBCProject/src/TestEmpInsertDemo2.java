import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class TestEmpInsertDemo2 {

	public static void main(String[] args)
	{
		Connection con=null;
		Statement st=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String uid="system";
		String pwd="corp123";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter empoyee id: ");
		int eid=sc.nextInt();
		System.out.println("Enter employee name: ");
		String nm=sc.next();
		System.out.println("Enter employee salary: ");
		float esal=sc.nextFloat();
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection(url,uid,pwd);
			pst=con.prepareStatement(QueryMapper.INSERTQRY3);
			pst.setInt(1, eid);
			pst.setString(2, nm);
			pst.setFloat(3, esal);
			int data=pst.executeUpdate();
			System.out.println("Data is inserted");
			
		
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}
}

