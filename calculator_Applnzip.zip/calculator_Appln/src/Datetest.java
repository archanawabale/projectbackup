import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

    public class Datetest {

        public static void main(String[] args) throws ParseException {

            String dateString = "03/04/2013";
            Date utiDate;
            SimpleDateFormat dateFormater = new SimpleDateFormat("dd/MM/yyyy");
            utiDate = dateFormater.parse (dateString);
            System.out.println(utiDate);
        }
    }