
public class InputNegativeException extends Exception {
	
	private String errMsg;

	public InputNegativeException(String errMsg) {
		
		this.errMsg = errMsg;
	}
	public InputNegativeException()
	{
		System.err.println("Negative data not accepted");
	}
	
	public String toString ()
	{
		return errMsg;
		
	}
	
	

}
