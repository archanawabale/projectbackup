package calci_test;

import static org.junit.Assert.*;

import org.junit.Test;

import calculator_Appln.Calci;
import calculator_Appln.InputNegativeException;

public class CalciTest {
Calci c = new Calci();
	@Test
	public void testAdd() {
		try {
			c.setNum1(-5);
		} catch (InputNegativeException e) {
			// TODO Auto-generated catch block
			System.err.println(e);
		}
		assertTrue(c.getNum1()>0);
		
		try {
			c.setNum2(7);
		} catch (InputNegativeException e) {
			// TODO Auto-generated catch block
			System.err.println(e);
		}
		assertTrue(c.getNum2()>0);	
		
	}

}
