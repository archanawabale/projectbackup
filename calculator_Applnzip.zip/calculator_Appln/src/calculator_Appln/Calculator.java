package calculator_Appln;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calci c = new Calci();
		boolean error= false;
		do
		{
		try {
			System.out.println("enter frst num");
			Scanner sc = new Scanner(System.in);
			int num1= sc.nextInt();
			c.setNum1(num1);
			error= false;
		} catch (InputNegativeException e) {
			// TODO Auto-generated catch block
			System.err.println(e);
			error= true;
		}
		}while(error);
		
		
		
		do
		{
		try {
			System.out.println("enter second num");
			Scanner sc2 = new Scanner(System.in);
			int num2= sc2.nextInt();
			c.setNum2(num2);
			error= false;
		} catch (InputNegativeException e) {
			// TODO Auto-generated catch block
			error= true;
			System.err.println(e);
		}
		}while(error);
		
		c.displayResul();
	

	}

}
