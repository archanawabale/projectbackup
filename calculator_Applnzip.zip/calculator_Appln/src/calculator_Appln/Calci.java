package calculator_Appln;

public class Calci {
	
	

private int num1;
private int num2;
public int getNum1() {
	return num1;
}
public void setNum1(int num1) throws InputNegativeException{
	if(num1<0)
		throw new InputNegativeException();
	else
	this.num1 = num1;
}
public int getNum2()  {
	return num2;
}
public void setNum2(int num2) throws InputNegativeException{
	if(num2<0)
		throw new InputNegativeException();
	this.num2 = num2;
}

public  int add(int a, int b){
	return a+b;
	
}
public void displayResul()
{
	System.out.println("Result "+ add(getNum1(),getNum2()));
}


}