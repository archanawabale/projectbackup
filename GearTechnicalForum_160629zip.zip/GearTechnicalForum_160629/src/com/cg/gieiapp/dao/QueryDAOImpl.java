package com.cg.gieiapp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.gieiapp.dto.Client;

@Repository("querydao")
public class QueryDAOImpl implements IQueryDAO{

	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public Client updateform(Client queries) {
		// TODO Auto-generated method stub
		Client client=entitymanager.merge(queries);
		entitymanager.flush();
		return client;
	}

	@Override
	public int searchId(int id) {
		// TODO Auto-generated method stub
		return id;
	}
	
	public Client fetch(int queryId) {
		Client client=entitymanager.find(Client.class, queryId);
		return client;
	}

	}
