package com.cg.gieiapp.dao;

import com.cg.gieiapp.dto.Client;

public interface IQueryDAO {

	
	public Client updateform(Client client) ;
	public int searchId(int id);
	public Client fetch(int queryId);
}
