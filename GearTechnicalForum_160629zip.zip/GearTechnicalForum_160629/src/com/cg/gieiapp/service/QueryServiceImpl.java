package com.cg.gieiapp.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.gieiapp.dao.IQueryDAO;
import com.cg.gieiapp.dto.Client;

@Service("queryservice")
@Transactional
public class QueryServiceImpl implements IQueryService{

	@Autowired
	IQueryDAO querydao;
	
	@Override
	public int searchId(int id) {
		// TODO Auto-generated method stub
		return querydao.searchId(id);
		
	}

	@Override
	public Client updateform(Client client) {
		// TODO Auto-generated method stub
		return querydao.updateform(client);
	}

	@Override
	public Client fetch(int client) {
		// TODO Auto-generated method stub
		return querydao.fetch(client);
	}
}
