package com.cg.gieiapp.service;

import com.cg.gieiapp.dto.Client;

public interface IQueryService {

	public Client updateform(Client client) ;
	public int searchId(int id);
	public Client fetch(int queryId);
	}

