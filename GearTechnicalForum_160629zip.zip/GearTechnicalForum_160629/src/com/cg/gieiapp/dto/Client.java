package com.cg.gieiapp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="query_master")
public class Client {

	public Client() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Id
	@Column(name="query_id",length=10)
	@NotNull(message="Query ID cannot be blank")
	private Integer queryId;
	
	@Column(name="technology",length=20)
	@NotNull(message="Technology cannot be blank")
	private String technology;
	
	@Column(name="query_raised_by",length=20)
	@NotNull(message="Query raised by cannot be blank")
	private String queryRaisedBy;
	
	@Column(name="query",length=20)
	@NotNull(message="Query cannot be blank")
	private String query;
	
	@Column(name="solutions",length=20)
	private String solutions;
	
	@Column(name="solution_given_by",length=20)
	private String solutionGivenBy;
	
	public Integer getQueryId() {
		return queryId;
	}
	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getQueryRaisedBy() {
		return queryRaisedBy;
	}
	public void setQueryRaisedBy(String queryRaisedBy) {
		this.queryRaisedBy = queryRaisedBy;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getSolutions() {
		return solutions;
	}
	public void setSolution(String solutions) {
		this.solutions = solutions;
	}
	public String getSolutionGivenBy() {
		return solutionGivenBy;
	}
	public void setSolutionGivenBy(String solutionGivenBy) {
		this.solutionGivenBy = solutionGivenBy;
	}
	public Client(int queryId, String technology, String queryRaisedBy,
			String query, String solutions, String solutionGivenBy) {
		super();
		this.queryId = queryId;
		this.technology = technology;
		this.queryRaisedBy = queryRaisedBy;
		this.query = query;
		this.solutions = solutions;
		this.solutionGivenBy = solutionGivenBy;
	}
	
	
	
}
