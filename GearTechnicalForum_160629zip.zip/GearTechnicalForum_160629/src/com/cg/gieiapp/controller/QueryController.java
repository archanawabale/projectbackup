package com.cg.gieiapp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.gieiapp.dto.Client;
import com.cg.gieiapp.service.IQueryService;


@Controller
public class QueryController {

	@Autowired
	IQueryService queryservice;
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		System.out.println("in all");
		return "home";
	}

	@RequestMapping(value="search", method=RequestMethod.GET)
	public ModelAndView form(@RequestParam("queryId") int queryId,Client query,  Model model) 
	{
		System.out.println("in search");
		Client queryRes =queryservice.fetch(query.getQueryId());
		if(queryRes==null || queryRes.getQueryId()==0)
		{
			int id=query.getQueryId();
			return new ModelAndView("failure","id",id);
		}
		else
		{
		Client query1=new Client();
		query1 = queryservice.fetch(queryId);
		query1.setQueryId(query.getQueryId());
		List<String> list= new ArrayList<String>();
		list.add("Purva");
		list.add("Rashi");
		list.add("Hina");
		list.add("Tara");
		model.addAttribute("list", list);
		model.addAttribute("queryRes", query1);
		return new ModelAndView("form");
		}
	}
	
	@RequestMapping(value="updatequery"/*, method=RequestMethod.POST*/)
	public String updateTrainee(@ModelAttribute("queryRes") Client client, Model model ) {
		System.out.println("in update" + client.getSolutions());
		queryservice.updateform(client);
		return "submitsuccess";
		
	}
	
}


