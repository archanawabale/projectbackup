package com.cg.mobile.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mobile.dao.IMobileDAO;
import com.cg.mobile.dto.Mobiles;

@Service("mobileservice")
@Transactional
public class MobileServiceImpl implements IMobileService{

	@Autowired
	IMobileDAO mobiledao;
	
	
	@Override
	public List<Mobiles> getAllMobiles() {
		// TODO Auto-generated method stub
		return mobiledao.getAllMobiles();
	}

	@Override
	public int addmobile(Mobiles mobile) {
		// TODO Auto-generated method stub
		return mobiledao.addmobile(mobile);
	}

	@Override
	public void delete(int mobileId) {
		// TODO Auto-generated method stub
		mobiledao.delete(mobileId);
		
	}

	@Override
	public Mobiles getMobiledetails(int mobileId) {
		// TODO Auto-generated method stub
		return mobiledao.getMobiledetails(mobileId);
	}

	@Override
	public Mobiles updatemobile(Mobiles mobile) {
		// TODO Auto-generated method stub
		return mobiledao.updatemobile(mobile);
	}

	@Override
	public List<Mobiles> deletemobile(int mobileId) {
		// TODO Auto-generated method stub
		return mobiledao.deletemobile(mobileId);
	}

}
