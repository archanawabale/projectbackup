package com.cg.mobile.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobile.dto.Mobiles;
import com.cg.mobile.service.IMobileService;

@Controller
public class MobileController {

	@Autowired
	IMobileService mobileservice;
	

	@RequestMapping("getmoblist")
	public String showMobileList(Model model){
		System.out.println("1111111111");
		List<Mobiles> list=mobileservice.getAllMobiles();
		System.out.println("2222222222");
		model.addAttribute("mobile", list);
		return "home";
	}
	

	@RequestMapping(value="insertmob",method=RequestMethod.GET)
	public String insertm(@ModelAttribute("my") Mobiles mobile){
		
		return "insert";
	}
	
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public ModelAndView insertmobile(@ModelAttribute("my") Mobiles mobile, BindingResult result, Model model){
		int id=mobileservice.addmobile(mobile);
		return new ModelAndView("addsuccess", "mobileid", id); 
	}

	@RequestMapping(value="deletemob",method=RequestMethod.GET)
	public String deletem(@ModelAttribute("my") Mobiles mobile){
		
		return "delete";
	}
	
	@RequestMapping(value="deletedata",method=RequestMethod.POST)
	public ModelAndView deletemobile(@RequestParam("mobileId") int mobileId, Model model){
		mobileservice.delete(mobileId);
		return new ModelAndView("deletesuccess", "mobid", mobileId); 
	}
	
	@RequestMapping("getUpdatePage")
	public String updatem(@RequestParam("mobileId") int mobileId, Model  model){
		
		Mobiles mobile=mobileservice.getMobiledetails(mobileId);
		if(mobile==null)
		{
			model.addAttribute("errmsg", "Mobile id is invalid"+mobileId);
			return "index1";
		}
		else
		{
			model.addAttribute("mobile", mobile);
			return "updatepage1";
		}
	}
	
	@RequestMapping("updatedata")
	public String updateMobile(@ModelAttribute("mobile") Mobiles mobile, Model model){
		Mobiles mobile2=mobileservice.updatemobile(mobile);
		model.addAttribute("mobile",mobile2);
		List<Mobiles> list=mobileservice.getAllMobiles();
		model.addAttribute("mobile", list);
		return "home";
	}
	
	@RequestMapping("delete")
	public String deletemob(@RequestParam("mobileId") int mobileId, Model model){
		List<Mobiles> list=mobileservice.deletemobile(mobileId);
		model.addAttribute("mobile",list);
		return "home";
	}
	
}
