package com.cg.mobile.dao;

import java.util.List;

import com.cg.mobile.dto.Mobiles;

public interface IMobileDAO {

	public List<Mobiles> getAllMobiles();
	public int addmobile(Mobiles mobile);
	public void delete(int mobileId);
	public Mobiles getMobiledetails(int mobileId);
	public Mobiles updatemobile(Mobiles mobile);
	public List<Mobiles> deletemobile(int mobileId);
}
