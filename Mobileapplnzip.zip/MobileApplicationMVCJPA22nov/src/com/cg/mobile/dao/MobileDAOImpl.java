package com.cg.mobile.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.mobile.dto.Mobiles;

@Repository("mobiledao")
public class MobileDAOImpl implements IMobileDAO{

	@PersistenceContext
	EntityManager entitymanager;
	
		
	@Override
	public List<Mobiles> getAllMobiles() {
		System.out.println("in dao class");
		String str="select mobile from Mobiles mobile";
		TypedQuery<Mobiles>query=entitymanager.createQuery(str,Mobiles.class);
		return query.getResultList();
	}

	@Override
	public int addmobile(Mobiles mobile) {
		// TODO Auto-generated method stub
		entitymanager.persist(mobile);
		entitymanager.flush();
		return mobile.getMobileId();
	}

	@Override
	public void delete(int mobileId) {
		// TODO Auto-generated method stub
		Query q=entitymanager.createQuery("DELETE FROM Mobiles WHERE mobileId=:mobileId");
		q.setParameter("mobileId",mobileId);
		q.executeUpdate();
	}

	@Override
	public Mobiles getMobiledetails(int mobileId) {
		// TODO Auto-generated method stub
		Mobiles mobile=entitymanager.find(Mobiles.class,mobileId);
		return mobile;
		
	}

	@Override
	public Mobiles updatemobile(Mobiles mobile) {
		// TODO Auto-generated method stub
		Mobiles mobile1=entitymanager.merge(mobile);
		return mobile1;
	}

	@Override
	public List<Mobiles> deletemobile(int mobileId) {
		// TODO Auto-generated method stub
		Mobiles mobile=getMobiledetails(mobileId);
		entitymanager.remove(mobile);
		return getAllMobiles();
	}

	

}
