import java.util.Scanner;

import com.cg.bean.Author;
import com.cg.dao.AuthorDao;


public class TestAuthorClientDemo {
	
	public static void main(String[] args)
	{

	AuthorDao auDao=new AuthorDao();
	Scanner sc=new Scanner(System.in);
	/*System.out.println("Enter author id: ");
	int aid=sc.nextInt();
	System.out.println("Enter first name: ");
	String fn=sc.next();
	System.out.println("Enter middle name: ");
	String mn=sc.next();
	System.out.println("Enter last name: ");
	String ln=sc.next();
	Author aut=new Author();
	aut.setAuthorId(aid);
	aut.setFirstName(fn);
	aut.setMiddleName(mn);
	aut.setLastName(ln);
	Author au=auDao.addAuthor(aut);
	System.out.println(au + " Author added successfully");*/
	
	/*System.out.println("Delete 107 roll no:");
	System.out.println("Record deleted for : "+ auDao.deleteAuthor(107));*/
	
	System.out.println("---------Update author name----------");
	Author au2=auDao.updateAuthor(102, "Misha", "Shahid", "Kapoor");
	System.out.println("updated  " +au2);
	
	
}

}