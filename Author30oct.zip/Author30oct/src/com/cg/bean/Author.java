package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="Author")
public class Author {

		@Id
		@Column(name="author_id", length=10 )
		private int authorId;
		
		@Column(name="first_name", length=10 )
		private String firstName;
		
		@Column(name="middle_name", length=10 )
		private String middleName;
		
		@Column(name="last_name", length=10 )
		private String lastName;
		
		@Transient
		private Long phoneNo;
		
		public int getAuthorId() {
			return authorId;
		}
		public void setAuthorId(int authorId) {
			this.authorId = authorId;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getMiddleName() {
			return middleName;
		}
		public void setMiddleName(String middleName) {
			this.middleName = middleName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public Long getPhoneNo() {
			return phoneNo;
		}
		public void setPhoneNo(Long phoneNo) {
			this.phoneNo = phoneNo;
		}
		@Override
		public String toString() {
			return "Author [authorId=" + authorId + ", firstName=" + firstName
					+ ", middleName=" + middleName + ", lastName=" + lastName
					+ ", phoneNo=" + phoneNo + "]";
		}
		public Author(int authorId, String firstName, String middleName,
				String lastName, Long phoneNo) {
			super();
			this.authorId = authorId;
			this.firstName = firstName;
			this.middleName = middleName;
			this.lastName = lastName;
			this.phoneNo = phoneNo;
		}
		public Author() {
			super();
			
		}
		

	

}
