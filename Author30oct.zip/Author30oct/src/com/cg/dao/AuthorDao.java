package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.bean.Author;
import com.cg.util.AuthorJPAUtil;

public class AuthorDao {
	
	EntityTransaction tran=null;
	EntityManager em=null;
	
	public AuthorDao()
	{
		em=AuthorJPAUtil.getEntityManager();
	}

	public Author addAuthor(Author au)
	{
		
		tran=em.getTransaction();
		tran.begin();
		em.persist(au);
		tran.commit();
		return au;
		
	}
	
	public Author updateAuthor(int aid,String newName, String newmiddleName, String newlastName)
	{
		Author at=new Author();
		at.setAuthorId(aid);
		at.setFirstName(newName);
		at.setMiddleName(newmiddleName);
		at.setLastName(newlastName);
		tran=em.getTransaction();
		tran.begin();
		em.merge(at);
		tran.commit();
		return at;
	}
	
	public Author deleteAuthor(int authorNo)
	{
		Author aum=em.find(Author.class, authorNo);
		tran=em.getTransaction();
		tran.begin();
		em.remove(aum);
		tran.commit();
		return aum;
	}
}
