import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.bean.Author;
import com.cg.bean.Book;
import com.cg.dao.AuthorDao;
import com.cg.util.*;

public class TestAuthorClientDemo {
	
	static EntityManager em=null;
	static AuthorDao auDao=null;
	public static void main(String[] args)
	{
		
	em=AuthorJPAUtil.getEntityManager();
	auDao=new AuthorDao();
	EntityTransaction tran=em.getTransaction();
	Scanner sc=new Scanner(System.in);
	
	Author  a1=new Author();
	a1.setAuthorId(101);
	a1.setAuthorName("Durjoy");
	
	Author  a2=new Author();
	a2.setAuthorId(102);
	a2.setAuthorName("Aruna");
	
	
	
	Set<Author> aSet = new HashSet<Author>();
	aSet.add(a1);
	aSet.add(a2);
	
	Book b1=new Book();
	b1.setIsbn(1234);
	b1.setTitle("The ring");
	b1.setPrice(1090.0F);
	
	Book b2=new Book();
	b2.setIsbn(5767);
	b2.setTitle("Wings of fire");
	b2.setPrice(1632.0F);
	b2.setAuthors(aSet);
	
	Set<Book> bSet = new HashSet<Book>();
	bSet.add(b1);
	bSet.add(b2);
	Author  a3=new Author();
	a3.setAuthorId(103);
	a3.setAuthorName("Mau");
	a3.setBooks(bSet);
	
	Book b3=new Book();
	b3.setIsbn(7856);
	b3.setTitle("The alchemist");
	b3.setPrice(600.0F);
	
	tran.begin();
	em.persist(a1);
	em.persist(a2);
	em.persist(a3);
	em.persist(b1);
	em.persist(b2);
	em.persist(b3);
	tran.commit();
	System.out.println("Data is added");

	
	
}

}