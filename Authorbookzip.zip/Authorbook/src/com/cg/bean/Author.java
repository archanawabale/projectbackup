package com.cg.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="Authors")
public class Author {

		@Id
		@Column(name="author_id", length=10 )
		private int authorId;
		
		@Column(name="author_name", length=10 )
		private String authorName;
		 
		
		public Set<Book> getBooks() {
			return books;
		}
		public void setBooks(Set<Book> books) {
			this.books = books;
		}
		@ManyToMany(cascade = CascadeType.ALL)
		@JoinTable(name = "author_book",
		joinColumns = { @JoinColumn(name ="book_isbn") }, 
		inverseJoinColumns = { @JoinColumn(name = "author_id") } )
		private Set<Book> books = new HashSet<>();
		
		public int getAuthorId() {
			return authorId;
		}
		public void setAuthorId(int authorId) {
			this.authorId = authorId;
		}
		
		public String getAuthorName() {
			return authorName;
		}
		public void setAuthorName(String authorName) {
			this.authorName = authorName;
		}
		@Override
		public String toString() {
			return "Author [authorId=" + authorId + ", authorName="
					+ authorName + ", books=" + books + "]";
		}
		public Author(int authorId, String authorName, Set<Book> books) {
			super();
			this.authorId = authorId;
			this.authorName = authorName;
			this.books = books;
		}
		public Author() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		
		
		
		

	

}
