package com.cg.bean;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="Books")
public class Book {

	@Id
	@Column(name="ISBN_CODE", length=10)
	private int isbn;
	
	@Column(name="book_title", length=20)
	private String title;
	
	@Column(name="price_rs", length=10)
	private float price;
	
	@ManyToMany(mappedBy="books")
	private Set<Author> authors;

	public int getIsbn() {
		return isbn;
	}

	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Set<Author> getAuthors() {
		return authors;
	}

	public void setAuthors(Set<Author> authors) {
		this.authors = authors;
	}

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", price=" + price
				+ ", authors=" + authors + "]";
	}

	public Book() {
		super();
		
	}

	public Book(int isbn, String title, float price, Set<Author> authors) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.price = price;
		this.authors = authors;
	}

	
	
}
