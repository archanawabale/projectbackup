package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.util.AuthorJPAUtil;

public class AuthorDao {
	
	EntityTransaction tran=null;
	EntityManager em=null;
	
	public AuthorDao()
	{
		em=AuthorJPAUtil.getEntityManager();
	}

	/*public Author addAuthor(Author au)
	{
		
		tran=em.getTransaction();
		tran.begin();
		em.persist(au);
		tran.commit();
		return au;
		
	}*/
	
	
	
	
}
