package com.capg.ems.service;

import com.capg.ems.bean.Employee;
import com.capg.ems.dao.EmpDAOImp;

public class EmpServiceImp implements IEmpService {
    
	EmpDAOImp dao= new EmpDAOImp();
	
	
	@Override
	public int addEmp(Employee e) {
		// TODO Auto-generated method stub
		int n= dao.addEmp(e);
		return n;
	}

}
