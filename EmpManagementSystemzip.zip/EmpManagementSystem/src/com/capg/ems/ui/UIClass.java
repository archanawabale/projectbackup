package com.capg.ems.ui;

import java.util.Scanner;

import com.capg.ems.bean.Employee;
import com.capg.ems.service.EmpServiceImp;

public class UIClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   System.out.println("Welcome to EMS");
   
   System.out.println("1. Add Employee");
   System.out.println("2. Display Employee");
   
   Scanner sc= new Scanner(System.in);
   
   int choice= sc.nextInt();
   EmpServiceImp service = new EmpServiceImp();
	   switch (choice) {
	case 1:
		System.out.println("Enter id/name/salary");
		int eid= sc.nextInt();
		String ename=sc.next();
		double salary=sc.nextDouble();
		
		Employee e= new Employee();
		e.setEid(eid);
		e.setEname(ename);
		e.setSalary(salary);
		
		int n= service.addEmp(e);
		
		if(n>0)
			System.out.println("Record added");
		
		break;
    case 2:
		
		
		break;

		
	default:
		break;
	}
	}

}
