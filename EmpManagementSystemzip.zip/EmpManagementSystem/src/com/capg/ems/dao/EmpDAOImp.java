package com.capg.ems.dao;

import com.capg.ems.bean.Employee;

public class EmpDAOImp implements IEmpDAO {

	@Override
	public int addEmp(Employee e) {
		// TODO Auto-generated method stub
		return 0;
	}

}
 