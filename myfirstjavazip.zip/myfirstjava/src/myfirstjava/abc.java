package myfirstjava;

public class abc {
	public static void main(String[] args){
		System.out.println("");

	}

}
