package com.cg.productmgmt.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import com.cg.ems.dto.Employee;
import com.cg.productmgmt.bean.ProductMgmt;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductException;
import com.cg.productmgmt.service.ProductService;

public class Client {

	static Scanner sc=null;
	static IProductService productSer;
	ProductMgmt client=new ProductMgmt();
	public static void main(String[] args) throws ProductException {

		sc=new Scanner(System.in);
		productSer=new ProductService();
		int choice=0;
		while(true)
		{
			System.out.println("Select an option :");
			System.out.println("1.Update Product Price \t 3.Exit\n");

			choice=sc.nextInt();
			switch(choice)
			{
			case 1: updatePrice();
					break;
			case 2: exit();
			default: System.exit(0);

			}

		}
	}
	private static void exit() {
	
		System.exit(0);
	}
	private static void updatePrice() {
		System.out.println("Enter the Product Category: ");
		String Category = sc.next();
		System.out.println("Enter hike Rate: ");
		int hike = sc.nextInt();
		try {
			if(productSer.validateHikeRate(hike))
			{
				System.out.println("in updte price");
				int result=productSer.updateProducts(Category, hike);
				if(result==1){
				System.out.println(Category +" Updated Successfully"); }
				Map<String, Integer> pc=productSer.getProductDetails();
				Iterator<ProductMgmt> it= pc.iterator();
				System.out.println("-------------------------------");
				System.out.println("EMPID/t/tEMPNAME\t\tEMPSalary");
				while(it.hasNext())
				{
					Employee ee=it.next();
					System.out.println(ee.getEmpId()+"\t\t"+ee.getEmpName()+"\t\t"+ee.getEmpSal()+"\t\t" + ee.getEmpDOJ()+"\t\t");
					
				}
				System.out.println("----------------------------------");
			}
		}
		catch( ProductException e)
		{
			e.printStackTrace();
		}
		

	}
	
}
