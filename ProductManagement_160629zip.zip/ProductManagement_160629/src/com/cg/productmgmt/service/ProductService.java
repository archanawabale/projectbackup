package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.bean.ProductMgmt;
import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;

public class ProductService implements IProductService {

	IProductDAO productDAO=new ProductDAO();
	
	@Override
	public int updateProducts(String Category, int hike)
			throws ProductException {
		
		return productDAO.updateProducts(Category, hike);
	}

	@Override
	public Map<String, Integer> getProductDetails() throws ProductException {
		
		return productDAO.getProductDetails();
	}

	

	public boolean validateHikeRate(int hike) {
		if(hike>0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
