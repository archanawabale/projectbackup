
public class TestMaxFinder {

	public static void main(String[] args){
		
	
	MaxFinder mf=(x,y)-> ((x>y)?x:y);
	int greatest=mf.max(70,90);
	System.out.println("Greatest number:"+ greatest);
}

}