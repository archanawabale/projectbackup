//to find the greatest of the two numbers
@FunctionalInterface
public interface MaxFinder {

	public int max(int num1, int num2)
	{
		
	}
}
