import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class TestDateDemo {

	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		LocalDate today=LocalDate.now();
		System.out.println("Today is : "+ today);
		LocalDateTime todaytime=LocalDateTime.now();
		System.out.println("Today day with time is:"+ todaytime);
		
		System.out.println("Enter year of joining:");
		int year=sc.nextInt();
		System.out.println("Enter month of joining:");
		int month=sc.nextInt();
		System.out.println("Enter date of joining:");
		int date=sc.nextInt();
		
		LocalDate myDOJ= LocalDate.of(year, month, date);
		System.out.println("My DOJ is :" + myDOJ);
		
		System.out.println("*****************************");
		System.out.println("Enter date of birth : (dd-mm-yyyy)");
		String dob=sc.next();
		DateTimeFormatter myFormater=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate myDOB= LocalDate.parse(dob, myFormater);
		System.out.println("My DOB : "+ myDOB);
		
		System.out.println("********From local date to string ******");
	    String myStrDOJ= myDOJ.format(DateTimeFormatter.ofPattern("dd-MMM-yyyy"));
	    System.out.println("DOJ: "+ myStrDOJ);
	    
	    System.out.println("********************************");
	    
	    Period per=Period.between(today, myDOB);
	    int mon=per.getMonths();
	    int yr=per.getYears();
	    int dy=per.getDays();
	    System.out.println("I am: "+ yr + ": " +mon +": "+dy +" days old");
	}
}
