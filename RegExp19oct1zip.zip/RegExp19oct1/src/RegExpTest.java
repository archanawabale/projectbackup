import java.util.Scanner;
import java.util.regex.*;


public class RegExpTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String inputStr="Test String";
		String patern="Test String";
		boolean patternMatched= Pattern.matches(patern, inputStr); 
		System.out.println(patternMatched);
		
		String input = "Shop, Mop, Hopping, Chopping";
		Pattern pattern= Pattern.compile("hop");
		Matcher matcher = pattern.matcher(input);
		
		while(matcher.find())
		{
			System.out.println(matcher.group() + ": "+ matcher.start() + ": " + matcher.end());
			
		}
		
		System.out.println("***************************");
		Scanner sc=new Scanner(System.in);
		System.out.println("******Enter Ur name*******");
		String firstName =sc.next();
		
		String firstnamePattern="[A-Z][a-z]+";
		if(Pattern.matches(firstnamePattern, firstName))
		{
			System.out.println("Valid Name");
		}
		else
		{
			System.out.println("Invalid name, Should have Only charachters and should start with Capital Letters");
			
		}
		

	}

}
