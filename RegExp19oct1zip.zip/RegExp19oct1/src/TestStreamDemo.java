
import java.util.Arrays;
import java.util.Comparator;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;


public class TestStreamDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("***********Filter*************");
		System.out.println("Print int greater than 11");
		List<Integer> listInt1 = Arrays.asList(11,3,44,5,66,33,44,3);
		
		
		System.out.println("---------------------------------");
		System.out.println("----find summation of numbers----");
		Optional<Integer> result=listInt1.stream().reduce((a,b)->a+b);
		if(result.isPresent())
		{
			System.out.println("Result :"+result.get());
		}
		
		System.out.println("--------------summation----------");
		System.out.println(listInt1.stream().reduce((a,b)->a+b).get());
		/*Stream intOriStream= listInt1.stream();
		Predicate<Integer> predicate=(Integer num)-> num>10;
		intOriStream.filter(predicate);
		Stream filteredIntStrm=intOriStream.filter(predicate);
		filteredIntStrm.forEach(num->System.out.print(" "+num)); */
		
		listInt1.stream().filter((num)->num>11)
		.forEach(num->System.out.print(" " +num));
		
		System.out.println("  ");
		System.out.println("****Print unique entry from list*******");
		listInt1.stream().distinct().forEach(System.out::println);
		
		System.out.println("****************************");
		List<String> citylist = Arrays.asList("Pune","Mumbai","","Pune","Chennai","Noida","Sahibabad","");
		long emptCity=citylist.stream().filter(str->str.isEmpty()).count();
		System.out.println("Empty str in the given cities is: " + emptCity);
		
		System.out.println("--------Length of each city name----");
		citylist.stream().map(str->str.length()).forEach(System.out::println);
		
		System.out.println("--------maximum number--------");
		System.out.println("Greatest number"+
		listInt1.stream().max(Comparator.naturalOrder()).get());
		System.out.println("Lowest number:"+ 
		listInt1.stream().min(Comparator.naturalOrder()).get());
		
		IntSummaryStatistics stats=listInt1.stream().mapToInt((x)->x).summaryStatistics();
		
		System.out.println(stats);
		System.out.println("Average number: "+ stats.getAverage());
	}

}
